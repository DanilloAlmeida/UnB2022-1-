#ifndef CONTROLADORASSERVICO_H_INCLUDED
#define CONTROLADORASSERVICO_H_INCLUDED

#include "dominios.h"
#include "entidades.h"
#include "interfaces.h"


//--------------------------------------------------------------------------------------------
// Declara��es de classes controladoras da camada de servi�os.
//
// Falta implementar c�digos.

class CntrServicoAutenticacao:public IServicoAutenticacao{
};

//--------------------------------------------------------------------------------------------

class CntrServicoPessoal:public IServicoPessoal{
};

//--------------------------------------------------------------------------------------------

class CntrServicoProdutosFinanceiros:public IServicoProdutosFinanceiros{
};

#endif // CONTROLADORASSERVICO_H_INCLUDED
