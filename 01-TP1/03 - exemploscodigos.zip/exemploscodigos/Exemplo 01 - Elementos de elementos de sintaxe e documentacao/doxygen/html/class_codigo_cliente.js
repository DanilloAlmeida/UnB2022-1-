var class_codigo_cliente =
[
    [ "CodigoCliente", "class_codigo_cliente.html#a72dbe2677b6e3cde4d93fe44034bc823", null ],
    [ "CodigoCliente", "class_codigo_cliente.html#a6f6358f08e44924e0a37e60bd004d5f4", null ],
    [ "getValor", "class_codigo_cliente.html#a4d42aa87c4a4fb2d91640c361c5dc548", null ],
    [ "setValor", "class_codigo_cliente.html#a3e9d0602103a0b799017b8e802f44b81", null ]
];