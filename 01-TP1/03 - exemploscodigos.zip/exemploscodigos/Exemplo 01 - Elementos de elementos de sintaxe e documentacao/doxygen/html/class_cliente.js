var class_cliente =
[
    [ "getContato", "class_cliente.html#a10393efb0749d9ba73dab285d97f79a5", null ],
    [ "setContato", "class_cliente.html#a2c6aa405c243d2a0d9e2d2a372095c9d", null ],
    [ "setContato", "class_cliente.html#a909993ee13de87b1e9978cc361d457d2", null ]
];