var class_conta_especial =
[
    [ "sacar", "class_conta_especial.html#abe5b4bc6f3b5df1d0c7b4ca189012d8c", null ]
];