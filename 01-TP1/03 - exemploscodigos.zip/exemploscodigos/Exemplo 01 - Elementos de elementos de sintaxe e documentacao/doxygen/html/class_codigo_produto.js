var class_codigo_produto =
[
    [ "CodigoProduto", "class_codigo_produto.html#a700b8eae3b4e0878611c6677ad50621c", null ],
    [ "getValor", "class_codigo_produto.html#abb4a0bd6a68e394b0879689ffd1fb483", null ],
    [ "setValor", "class_codigo_produto.html#afafd0d854ba28ad9c5f0eeef0d434391", null ]
];