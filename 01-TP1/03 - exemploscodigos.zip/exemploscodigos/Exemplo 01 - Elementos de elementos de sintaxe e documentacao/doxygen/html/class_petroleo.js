var class_petroleo =
[
    [ "Petroleo", "class_petroleo.html#af171512e6d46ff4d6683774fd85f209f", null ],
    [ "getOrigem", "class_petroleo.html#adcec8ac5ecfe2037d9b03d47ec3318fa", null ]
];