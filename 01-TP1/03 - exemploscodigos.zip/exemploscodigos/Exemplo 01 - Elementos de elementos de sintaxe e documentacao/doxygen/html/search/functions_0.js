var searchData=
[
  ['codigocliente_39',['CodigoCliente',['../class_codigo_cliente.html#a72dbe2677b6e3cde4d93fe44034bc823',1,'CodigoCliente::CodigoCliente()'],['../class_codigo_cliente.html#a6f6358f08e44924e0a37e60bd004d5f4',1,'CodigoCliente::CodigoCliente(int valor)']]],
  ['codigoproduto_40',['CodigoProduto',['../class_codigo_produto.html#a700b8eae3b4e0878611c6677ad50621c',1,'CodigoProduto']]]
];
