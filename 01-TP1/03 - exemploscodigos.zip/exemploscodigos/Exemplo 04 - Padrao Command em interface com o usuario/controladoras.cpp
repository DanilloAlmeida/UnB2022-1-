#include "controladoras.h"
#include "comandos.h"

//-----------------------------------------------------------------------------------
// Implmenta��es de m�todos de classe controladora.

bool CntrIAAutenticacao::autenticar(Matricula *matricula){

    bool resultado;
    Senha senha;
    int entrada;

    // Solicitar matricula e senha.

    while(true) {
        try {
            cout << "Digite a matricula : ";
            cin >> entrada;
            matricula->setValor(entrada);
            cout << "Digite a senha     : ";
            cin >> entrada;
            senha.setValor(entrada);
            break;
        }
        catch (const invalid_argument &exp) {
            cout << endl << "Dado em formato incorreto." << endl;
        }
    }

    resultado = cntrISAutenticacao->autenticar(*matricula, senha);  // Solicitar autentica��o.

    return resultado;                                               // Informar resultado da autentica��o.
}

//-----------------------------------------------------------------------------------
// Implmenta��es de m�todos de classe controladora.

void CntrIAGerente::executar(const Matricula &matricula){

    ComandoIAGerente *comando;

    int opcao;

    while(true){

        // Apresentar op��es.

        cout << endl << "Gerenciamento de Gerente." << endl << endl;
        cout << "Incluir   - " << INCLUIR << endl;
        cout << "Remover   - " << REMOVER << endl;
        cout << "Pesquisar - " << PESQUISAR << endl;
        cout << "Editar    - " << EDITAR << endl;
        cout << "Retornar  - " << RETORNAR << endl << endl;
        cout << "Selecione uma opcao :";

        cin >> opcao;

        switch(opcao){
            case INCLUIR:   comando = new ComandoIAGerenteIncluir();
                            comando->executar(cntrISGerente);
                            delete comando;
                            break;
            case REMOVER:   comando = new ComandoIAGerenteRemover();
                            comando->executar(cntrISGerente);
                            delete comando;
                            break;
            case PESQUISAR: comando = new ComandoIAGerentePesquisar();
                            comando->executar(cntrISGerente);
                            delete comando;
                            break;
            case EDITAR:    comando = new ComandoIAGerenteEditar();
                            comando->executar(cntrISGerente);
                            delete comando;
                            break;
        }
        if(opcao == RETORNAR){
            break;
        }
    }
    return;
}

